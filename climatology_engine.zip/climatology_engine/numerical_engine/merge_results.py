#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
numerical_engine/merge_results.py
================================================================================
جمع‌آوری نتایج ایستگاه‌ها در block_result.
================================================================================
"""

from zarr_schema import create_empty_block_result, VAR_NAMES

def merge_station_result(block_result, station_result, local_idx):
    for name in VAR_NAMES:
        block_result[name][:, local_idx] = station_result[name]

def create_and_merge_results(block_data, window_table, var_idx):
    from numerical_engine.analyze_station import analyze_station
    block_size = block_data.shape[0]
    block_result = create_empty_block_result(block_size)
    for local_idx in range(block_size):
        station_data = block_data[local_idx]
        station_result = analyze_station(station_data, window_table, var_idx)
        merge_station_result(block_result, station_result, local_idx)
    return block_result
